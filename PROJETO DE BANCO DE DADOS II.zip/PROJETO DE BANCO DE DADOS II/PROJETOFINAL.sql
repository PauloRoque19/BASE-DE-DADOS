use master

create database bd_auto_pecas

use bd_auto_pecas;

create table ESTOQUE(
	cod bigint not null constraint pk_estoque primary key,
	qntestoque int not null
)

create table CATEGORIA(
	cod bigint not null constraint pk_categoria primary key,
	nome varchar(50) not null ,
	descricao varchar(100)
)

create table TIPO(
	cod bigint not null constraint pk_tipo primary key,
	nome varchar(50) not null,
	descricao varchar(50),
	categoria bigint not null constraint fk_categoria foreign key references CATEGORIA(cod)

)

CREATE TABLE ENDERECO(
  rua VARCHAR(25) NOT NULL,
  numero int NOT NULL,
  cep VARCHAR(10) NOT NULL,
  cod BIGINT NOT NULL constraint pk_endereco primary key
)

create table CLIENTE(
	cod bigint not null constraint pk_cliente primary key,
	nome varchar(100) not null,
	fone varchar(12),
	endere�o bigint constraint fk_endere�o foreign key references ENDERECO(cod),
	cpf varchar(11) not null constraint un_cliente_cpf unique
)

create table PRODUTO(
	cod bigint not null constraint pk_produto primary key,
	estoque bigint not null constraint fk_estoque foreign key references ESTOQUE(cod),
	tipo bigint not null constraint fk_tipo foreign key references TIPO(cod),
	nome varchar(60) not null,
	preco smallmoney not null 
)

CREATE TABLE SETOR(
  nome VARCHAR(25) NOT NULL,
  cod BIGINT NOT NULL constraint pk_setor primary key,
  descricao VARCHAR(40) NOT NULL
)

create TABLE FUNCIONARIO(
  nome VARCHAR(100) NOT NULL,
  cpf VARCHAR(11)CONSTRAINT UN_CPF UNIQUE NOT NULL,
  cod BIGINT NOT NULL constraint pk_funcionario primary key,
 setor BIGINT NOT NULL
  CONSTRAINT FK_SETOR FOREIGN KEY
 REFERENCES SETOR(cod),
  funcao bigint not null constraint fk_funcao foreign key references FUNCAO(cod)
)


create table PEDIDO(
	cod bigint not null constraint pk_pedido primary key,
	vendedor bigint not null constraint fk_vendedor foreign key references FUNCIONARIO(cod),
	cliente bigint not null constraint fk_cliente foreign key references CLIENTE(cod),
	produto bigint not null constraint fk_produto foreign key references PRODUTO(cod)
)

CREATE TABLE VENDA(
 cod BIGINT NOT NULL
 CONSTRAINT PK_VENDA PRIMARY KEY,
 pedido BIGINT NOT NULL
 CONSTRAINT FK_PEDIDO FOREIGN KEY
 REFERENCES PEDIDO(cod)
)

CREATE TABLE FUNCAO(
  nome VARCHAR(25) NOT NULL,
  cod BIGINT NOT NULL constraint pk_funcao primary key,
  descricao VARCHAR(40) NOT NULL
)


CREATE TABLE ENTREGA(
 cod bigint  NOT NULL
 CONSTRAINT pk_entrega primary key,
 venda bigint constraint fk_venda foreign key references VENDA(cod),
 entregador bigint constraint fk_funcionario foreign key references FUNCIONARIO(cod)
)

