-- Procedures Projeto final

-- quantidade de pedidos realizados.

create procedure spQuantidadePedidosCliente
@cliente bigint
as
select COUNT(*) as 'quantidade' from PEDIDO where cliente = @cliente
	
execute spQuantidadePedidosCliente 1
-- nome dos produtos do pedido realizado pelo cliente

create procedure spNomeDosProdutoDoPedidoDoCliente
@cliente bigint
as
select produto from PEDIDO p inner join PRODUTO pro on p.produto = pro.cod where cliente = @cliente

execute spNomeDosProdutoDoPedidoDoCliente