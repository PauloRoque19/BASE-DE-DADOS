select * from CLIENTE
select * from ENDERECO

-- USADO PARA REPARAR ERROS NAS TABELAS :D 
--update CLIENTE set nome = 'Cesar Hugo de Carvalho' , fone = '977553236' where cod = 0

select * from CLIENTE c inner join ENDERECO e on c.endere�o = e.cod

-- INSERINDO CLIENTES NO BANCO
insert into ENDERECO values('Rua Nova', '234','58202123',1)
insert into CLIENTE values(1,'Paulo Henrique Roque da Silva','955443322',1,'32112356590')

insert into ENDERECO values('Rua Avenida Brasil', '998','59123456',2)
insert into CLIENTE values(2,'Jo�o Carlos Pereira Coutinho','967323487',2,'43217358570')

insert into ENDERECO values('Rua Getulio Vargas', '902','58310000',3)
insert into CLIENTE values(3,'Bruno Nilvan Cezar de Lima','967623887',3,'53917338570')

insert into ENDERECO values('Rua Jo�o Dias', '703','58310756',4)
insert into CLIENTE values(4,'Bruno Nilvan Cezar de Lima','967623887',4,'53914332572')

insert into ENDERECO values('Av Pedro Siqueira', '18','58295828',5)
insert into CLIENTE values(5,'Joselito Jos� da Silva','976254387',5,'52647388570')

insert into ENDERECO values('Rua Paulo Americo Golveia', '534','58294828',6)
insert into CLIENTE values(6,'Yago Pedro da Silva Machado','976557387',6,'52697328586')

insert into ENDERECO values('Rua Jos� Opling', '264','58245829',7)
insert into CLIENTE values(7,'Vinicius klingy Ulisses','976254367',7,'52437378572')

insert into ENDERECO values('Rua Jonh Terra', '292','58265829',8)
insert into CLIENTE values(8,'Killian Jonhata dos Santos','926554367',8,'82437378572')

insert into ENDERECO values('Rua Jonh Terra', '187','58265829',9)
insert into CLIENTE values(9,'Killian Jonhata dos Santos','926554367',9,'92237368560')

insert into ENDERECO values('Av Pedro Siqueira', '26','58295828',10)
insert into CLIENTE values(10,'Matheus Bruno dos Santos','936552367',10,'12237358562')

--INSERINDO CATEGORIA NO BANCO

select * from CATEGORIA

insert into CATEGORIA values(1,'ACABAMENTO EXTERNO','Pe�as para exterior do veiculo')
insert into CATEGORIA values(2,'ACABAMENTO INTERNO','Pe�as para interior do veiculo')
insert into CATEGORIA values(3,'ACESS�RIOS','Acessorios Aleat�rias')
insert into CATEGORIA values(4,'Alimenta��o de combust�vel','Pe�as para parte de combustivel')
insert into CATEGORIA values(5,'Amortecedores','Amortecedores para veiculo')
insert into CATEGORIA values(6,'Borrachas de veda��o','Pe�as em borracha para veda��o')
insert into CATEGORIA values(7,'ILUMINA��O','Pe�as de Veiculos para Ilumina��o')
insert into CATEGORIA values(8,'Latarias','Latarias diversos para veiculos')
insert into CATEGORIA values(9,'Fechaduras','Diversas fechaduras para veiculos')
insert into CATEGORIA values(10,'Retrovisores','Itens de categorias de retrovisores')

--INSERINDO TIPO NO BANCO

select * from TIPO

insert into TIPO values (1,'PALIO','Acabamento externo para Palio',1)
insert into TIPO values (2,'CORSA','Acabamento externo para Corsa',1)
insert into TIPO values (3,'GOL','Acabamento externo para Gol',1)
insert into TIPO values (4,'UNO','Acabamento externo para Uno',1)
insert into TIPO values (5,'Moby','Acabamento externo para Moby',1)
insert into TIPO values (6,'SIENA','Acabamento externo para Siena',1)
insert into TIPO values (7,'CELTA','Acabamento externo para Celta',1)
insert into TIPO values (8,'HB20','Acabamento externo para HB20',1)
insert into TIPO values (9,'ONIX','Acabamento externo para Onix',1)
insert into TIPO values (10,'FIESTA','Acabamento externo para Fiesta',1)

--INSERINDO PRODUTOS NO BANCO


--INSERINDO ESTOQUE NO BANCO

select * from ESTOQUE
--Estoque de capa de retrovisores
insert into ESTOQUE values(1,600)
insert into ESTOQUE values(2,450)
insert into ESTOQUE values(3,367)
insert into ESTOQUE values(4,786)
insert into ESTOQUE values(5,972)
insert into ESTOQUE values(6,858)
insert into ESTOQUE values(7,274)
insert into ESTOQUE values(8,582)
insert into ESTOQUE values(9,583)
insert into ESTOQUE values(10,968)

--INSERINDO DADOS NA TABELA SETOR
select * from SETOR

INSERT INTO SETOR VALUES('FINANCEIRO',1,'CUIDA DA PARTE FINANCEIRA DA EMPRESA.')
INSERT INTO SETOR VALUES('ALMOXARIFADO',2,'CUIDA DA CONSERVA��O DE MATERIAIS.')
INSERT INTO SETOR VALUES('LIMPEZA',3,'conserva��o de ambientes gerais.')
INSERT INTO SETOR VALUES('TI',4,'destinado  a tecnologia da empresa.')
INSERT INTO SETOR VALUES('RH',5,'destinado a Recursos Humanos.')
INSERT INTO SETOR VALUES('VENDAS',6,'destinado a Vendas .')
INSERT INTO SETOR VALUES('ASSISTENCIA TECNICA',7,'destinado a reparos gerais.')
INSERT INTO SETOR VALUES('TRANSPORTE',8,'destinado a transporte de pedidos.')
INSERT INTO SETOR VALUES('SUPORTE',9,'destinado a lidar com clientes.')
INSERT INTO SETOR VALUES('MARKETING',10,'promover os produtos da empresa.')

--INSERINDO DADOS NA TABELA FUNCAO
select * from FUNCAO

INSERT INTO FUNCAO VALUES('ANALISTA DE SISTEMAS',1,'Setor de TI.')
INSERT INTO FUNCAO VALUES('ANALISTA FINANCEIRO',2,'Setor de finan�as.')
INSERT INTO FUNCAO VALUES('SUPORTE TECNICO',3,'Setor de Suporte.')
INSERT INTO FUNCAO VALUES('VENDEDOR',4,'Setor de vendas.')
INSERT INTO FUNCAO VALUES('ENTREGADOR',5,'Setor de transporte.')
INSERT INTO FUNCAO VALUES('ANALISTA EM MARKETING',6,'Setor de Marketing.')
INSERT INTO FUNCAO VALUES('FAXINEIRO',7,'Setor de limpeza.')
INSERT INTO FUNCAO VALUES('GESTOR DE RECRUTAMENTO',8,'Setor de RH.')
INSERT INTO FUNCAO VALUES('MECANICO',9,'Setor de assistencia tecnica.')
INSERT INTO FUNCAO VALUES('ESTOQUISTA',10,'Setor de almoxarifado.')

-- INSERINDO FUNCIONARIOS NO BANCO
select * from FUNCIONARIO
--INSERINDO DADOS NA TABELA FUNCIONARIO
INSERT INTO ENDERECO values ('RUA PEDRO MACHADO TORRES',664,'58762485',11)
INSERT INTO FUNCIONARIO VALUES('MARCOS AURELIO','98654400080',1,1,2,11)

INSERT INTO ENDERECO values ('RUA PEDRO MACHADO TORRES',635,'58762485',12)
INSERT INTO FUNCIONARIO VALUES('JULIA GOLVEIA DE SOUZA','98254400082',2,2,10,12)

INSERT INTO ENDERECO values ('RUA PEDRO MACHADO FREITAS',635,'58762480',13)
INSERT INTO FUNCIONARIO VALUES('Joaquin Barbosa de Rocha','42091246050',3,3,7,13)

INSERT INTO ENDERECO values ('RUA PEDRO MACHADO FREITAS',374,'58762480',14)
INSERT INTO FUNCIONARIO VALUES('Paulo Junior dos Santos','43242346777',4,4,1,14)

INSERT INTO ENDERECO values ('RUA PEDRO MACHADO FREITAS',398,'58762480',15)
INSERT INTO FUNCIONARIO VALUES('Julho Cesar Jurema Pinto','43242346737',5,5,8,15)

INSERT INTO ENDERECO values ('RUA YHUGSNIS XAVIER',101,'58762489',16)
INSERT INTO FUNCIONARIO VALUES('Jo�o Pedro Correia','43242342737',6,6,4,16)

INSERT INTO ENDERECO values ('RUA YHUGSNIS XAVIER',112,'58762489',17)
INSERT INTO FUNCIONARIO VALUES('Neto Cavalcante de Kiote','43242642737',7,7,9,17)

INSERT INTO ENDERECO values ('RUA YHUGSNIS XAVIER',187,'58762489',18)
INSERT INTO FUNCIONARIO VALUES('Gustavo Mantovanni Teixeira','83242642737',8,8,5,18)

INSERT INTO ENDERECO values ('Av Jo�o Paulo Geto',75,'58762564',19)
INSERT INTO FUNCIONARIO VALUES('Gabriel Melo de Souza','83282642737',9,9,3,19)

INSERT INTO ENDERECO values ('Av Jo�o Paulo Geto',23,'58762564',20)
INSERT INTO FUNCIONARIO VALUES('Gabriel Melo de Souza','83282644737',10,10,6,20)


--INSERINDO DADOS NA TABELA DE PRODUTO
select * from PRODUTO

INSERT INTO PRODUTO VALUES(1,1,1,'Capa do retrovisor para Palio',125.0)
INSERT INTO PRODUTO VALUES(2,2,2,'Capa do retrovisor para Corsa',110.0)
INSERT INTO PRODUTO VALUES(3,3,3,'Aerofolio para GOL',469.0)
INSERT INTO PRODUTO VALUES(4,4,4,'Calha de chuva para Uno',120.0)
INSERT INTO PRODUTO VALUES(5,5,5,'Capa da ma�aneta para Moby',210.0)
INSERT INTO PRODUTO VALUES(6,6,6,'Espelho do Retrovisor Siena',54.0)
INSERT INTO PRODUTO VALUES(7,7,7,'Parachoque Dianteiro Celta',600.0)
INSERT INTO PRODUTO VALUES(8,8,8,'Farois Traseiros HB20',300.0)
INSERT INTO PRODUTO VALUES(9,9,9,'Antena de Radio para Onix',39.0)
INSERT INTO PRODUTO VALUES(10,10,10,'Limpador de Parabrisa Fiesta',60.0)

--INSERINDO DADOS NA TABELA PEDIDO

select * from PEDIDO

INSERT INTO PEDIDO VALUES (1,4,1,4)
INSERT INTO PEDIDO VALUES (2,4,2,10)
INSERT INTO PEDIDO VALUES (3,4,3,1)
INSERT INTO PEDIDO VALUES (4,4,4,9)
INSERT INTO PEDIDO VALUES (5,4,5,8)
INSERT INTO PEDIDO VALUES (6,4,6,5)
INSERT INTO PEDIDO VALUES (7,4,7,3)
INSERT INTO PEDIDO VALUES (8,4,8,2)
INSERT INTO PEDIDO VALUES (9,4,9,7)
INSERT INTO PEDIDO VALUES (10,4,10,6)

--Inserindo as Vendas Confirmadas
select * from VENDA

insert into VENDA values(1,1)
insert into VENDA values(2,2)
insert into VENDA values(3,3)
insert into VENDA values(4,4)
insert into VENDA values(5,5)
insert into VENDA values(6,6)
insert into VENDA values(7,7)
insert into VENDA values(8,8)
insert into VENDA values(9,9)
insert into VENDA values(10,10)

--INSERINDO A TABELA ENTREGA

select * from ENTREGA


INSERT INTO ENTREGA VALUES(1,1,5)
INSERT INTO ENTREGA VALUES(2,2,5)
INSERT INTO ENTREGA VALUES(3,3,5)
INSERT INTO ENTREGA VALUES(4,4,5)
INSERT INTO ENTREGA VALUES(5,5,5)
INSERT INTO ENTREGA VALUES(6,6,5)
INSERT INTO ENTREGA VALUES(7,7,5)
INSERT INTO ENTREGA VALUES(8,8,5)
INSERT INTO ENTREGA VALUES(9,9,5)
INSERT INTO ENTREGA VALUES(10,10,5)

