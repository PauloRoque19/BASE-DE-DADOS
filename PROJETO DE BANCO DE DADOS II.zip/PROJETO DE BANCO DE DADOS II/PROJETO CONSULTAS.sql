

update PEDIDO set vendedor = 6
--Scripts de Consultas

--Script de Consulta de Endere�o do cliente 
select c.nome as 'nome do cliente' ,e.rua , e.cep , e.numero from CLIENTE c inner join ENDERECO e on c.endere�o = e.cod where c.cod = 2

--Script de Consulta de nome do cliente do pedido
select c.nome from PEDIDO p  inner join CLIENTE c on p.cliente = c.cod where p.cod = 2
--Script de Consulta de Nome do Vendedor que fez a venda
select f.nome from VENDA v inner join PEDIDO p on v.pedido = p.cod inner join FUNCIONARIO f on p.vendedor= f.cod where v.cod = 8
--Script de Consulta do Local de Entrega da venda
select  ec.rua    , 
		ec.numero , 
        ec.cep    ,
		c.nome as 'nome do cliente',
		c.fone as 'fone do cliente'  from ENTREGA e  inner join VENDA v on e.venda = v.cod 
	inner join PEDIDO p on v.pedido = p.cod 
	inner join CLIENTE c  on p.cliente = c.cod 
	inner join ENDERECO ec on c.endere�o = ec.cod where e.cod = 3
--Script de Consulta da Fun��o do Funcionario
select f.nome as 'nome do funcionario' ,fc.nome as 'nome da fun��o', fc.descricao  from FUNCIONARIO f  inner join FUNCAO fc on f.funcao = fc.cod where f.cod = 6
--Script de Consulta da quantidade de tal produto
select p.nome as 'Produtos' , e.qntestoque from PRODUTO p  inner join ESTOQUE e on p.estoque = e.cod
--Script de Consulta da Categoria do produto
select p.nome as 'Produto' , c.nome as 'Categoria' from produto p inner join TIPO t on p.tipo = t.cod 
													inner join CATEGORIA c on t.categoria = c.cod 
													where p.cod = 1
--Script de Consulta do tipo do Produto
select p.nome as 'Produto' , t.nome as 'Tipo' from PRODUTO p inner join TIPO t on p.tipo = t.cod order by p.nome asc
--Script de Consulta do Endere�o do Funcionario
select * from FUNCIONARIO f inner join ENDERECO e on f.endereco = e.cod
 --Script de Consulta do nome do produto do pedido
select pro.nome as 'produto' , p.cliente from PEDIDO p inner join PRODUTO pro on p.produto = pro.cod order by pro.nome asc